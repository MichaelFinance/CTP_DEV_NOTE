直接双击“check_TCP_connect.bat”脚本，检查Sinnow CTP环境是否接通
